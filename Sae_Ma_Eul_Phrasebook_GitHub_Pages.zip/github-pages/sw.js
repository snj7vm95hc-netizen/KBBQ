
const CACHE='saemaeul-phrasebook-v1';
const ASSETS=['./','./index.html','./manifest.webmanifest','./icon.svg','./audio/Sae_Ma_Eul_Core_English.wav','./audio/Sae_Ma_Eul_Core_Chinese.wav','./audio/Sae_Ma_Eul_Core_Malay.wav','./audio/Sae_Ma_Eul_Core_Burmese.wav'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(res=>{const copy=res.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return res}).catch(()=>caches.match('./index.html'))))});
