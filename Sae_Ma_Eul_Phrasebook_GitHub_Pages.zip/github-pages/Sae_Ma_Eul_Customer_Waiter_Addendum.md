

---

## ၁၆။ စားပွဲပေါ်မှာ ရေ၊ လက်သုတ်ပဝါနှင့် ပန်းကန်ထပ်လိုခြင်း

**C:** Excuse me, could we have some water, please?  
**中文:** 不好意思，可以给我们一些水吗？ *Bù hǎoyìsi, kěyǐ gěi wǒmen yìxiē shuǐ ma?*  
**BM:** Maaf, boleh beri kami air?  
**မြန်မာ:** တောင်းပန်ပါတယ်၊ ရေနည်းနည်း ပေးလို့ရမလား။

**W:** Certainly. I’ll bring water and extra cups.  
**中文:** 当然可以，我拿水和额外的杯子给您。 *Dāngrán kěyǐ, wǒ ná shuǐ hé éwài de bēizi gěi nín.*  
**BM:** Boleh. Saya bawakan air dan cawan tambahan.  
**မြန်မာ:** ရပါတယ်။ ရေနဲ့ ခွက်အပို ယူလာပေးပါမယ်။

**C:** Could we have more napkins and small plates?  
**中文:** 可以给我们多一些纸巾和小盘子吗？ *Kěyǐ gěi wǒmen duō yìxiē zhǐjīn hé xiǎo pánzi ma?*  
**BM:** Boleh beri tisu dan pinggan kecil tambahan?  
**မြန်မာ:** တစ်ရှူးနဲ့ ပန်းကန်သေး အပို ပေးလို့ရမလား။

**W:** Yes, I’ll bring them now.  
**中文:** 可以，我现在拿来。 *Kěyǐ, wǒ xiànzài ná lái.*  
**BM:** Boleh, saya bawakan sekarang.  
**မြန်မာ:** ရပါတယ်၊ အခု ယူလာပေးပါမယ်။

---

## ၁၇။ အော်ဒါပြောင်းခြင်း / အပိုအော်ဒါမှာခြင်း

**C:** Can we add one more portion of beef?  
**中文:** 可以再加一份牛肉吗？ *Kěyǐ zài jiā yí fèn niúròu ma?*  
**BM:** Boleh tambah satu hidangan daging lembu?  
**မြန်မာ:** အမဲသားတစ်ပွဲ ထပ်မှာလို့ရမလား။

**W:** I’ll add one portion of beef. Would you like anything else?  
**中文:** 我帮您加一份牛肉。还需要别的吗？ *Wǒ bāng nín jiā yí fèn niúròu. Hái xūyào bié de ma?*  
**BM:** Saya tambah satu daging lembu. Ada apa-apa lagi?  
**မြန်မာ:** အမဲသားတစ်ပွဲ ထပ်ထည့်ပေးပါမယ်။ နောက်ထပ် ဘာလိုသေးပါသလဲ။

**C:** Can we remove the rice from our order?  
**中文:** 可以把米饭从订单里取消吗？ *Kěyǐ bǎ mǐfàn cóng dìngdān lǐ qǔxiāo ma?*  
**BM:** Boleh buang nasi daripada pesanan kami?  
**မြန်မာ:** အော်ဒါထဲက ထမင်းကို ဖျက်လို့ရမလား။

**W:** I’ll check whether it has already been prepared, then I’ll confirm.  
**中文:** 我先确认米饭是否已经准备好，再回复您。 *Wǒ xiān quèrèn mǐfàn shìfǒu yǐjīng zhǔnbèi hǎo, zài huífù nín.*  
**BM:** Saya semak sama ada nasi sudah disediakan, kemudian saya maklumkan.  
**မြန်မာ:** ထမင်းပြင်ပြီးပြီလား အရင်စစ်ပြီး ပြန်အသိပေးပါမယ်။

---

## ၁၈။ အသားကျက်မှု / မီးကင်ချိန် မေးခြင်း

**C:** Is the meat cooked through?  
**中文:** 肉熟了吗？ *Ròu shú le ma?*  
**BM:** Adakah daging sudah masak sepenuhnya?  
**မြန်မာ:** အသား ကျက်ပြီလား။

**W:** I’ll check the meat and help you grill it safely.  
**中文:** 我帮您确认肉是否熟了，也会安全地帮您烤。 *Wǒ bāng nín quèrèn ròu shìfǒu shú le, yě huì ānquán de bāng nín kǎo.*  
**BM:** Saya periksa daging dan bantu memanggang dengan selamat.  
**မြန်မာ:** အသားကျက်ပြီလား စစ်ပြီး ဘေးကင်းအောင် ကင်ပေးပါမယ်။

**C:** We prefer the meat well done, please.  
**中文:** 我们喜欢肉熟一点。 *Wǒmen xǐhuān ròu shú yìdiǎn.*  
**BM:** Kami mahu daging yang masak sepenuhnya.  
**မြန်မာ:** အသားကို ကျက်ကျက်လေး စားချင်ပါတယ်။

**W:** I understand. I’ll cook it a little longer and check it for you.  
**中文:** 明白，我再烤久一点并帮您确认。 *Míngbái, wǒ zài kǎo jiǔ yìdiǎn bìng bāng nín quèrèn.*  
**BM:** Baik, saya masak lebih lama sedikit dan periksa untuk anda.  
**မြန်မာ:** နားလည်ပါပြီ။ နည်းနည်း ထပ်ကင်ပြီး စစ်ပေးပါမယ်။

---

## ၁၉။ မီးကင်ဇကာ / မီးအပူ ပြောင်းပေးရန်

**C:** Could you change the grill? It is getting dirty.  
**中文:** 可以帮我们换烤网吗？烤网脏了。 *Kěyǐ bāng wǒmen huàn kǎowǎng ma? Kǎowǎng zāng le.*  
**BM:** Boleh tukar jaringan pemanggang? Ia sudah kotor.  
**မြန်မာ:** မီးကင်ဇကာ ညစ်လာပြီ။ လဲပေးလို့ရမလား။

**W:** Yes. Please move your hands away while I change it.  
**中文:** 可以。换的时候请把手移开。 *Kěyǐ. Huàn de shíhou qǐng bǎ shǒu yíkāi.*  
**BM:** Boleh. Sila jauhkan tangan semasa saya menukarnya.  
**မြန်မာ:** ရပါတယ်။ လဲနေတုန်း လက်ကို ဝေးဝေးထားပေးပါ။

**C:** The grill is too hot.  
**中文:** 烤炉太热了。 *Kǎolú tài rè le.*  
**BM:** Pemanggang terlalu panas.  
**မြန်မာ:** မီးကင်က အရမ်းပူတယ်။

**W:** I’ll reduce the heat and check the ventilation.  
**中文:** 我把火调小一点，也检查通风。 *Wǒ bǎ huǒ tiáo xiǎo yìdiǎn, yě jiǎnchá tōngfēng.*  
**BM:** Saya kecilkan api dan periksa pengudaraan.  
**မြန်မာ:** မီးအပူလျှော့ပြီး လေဝင်လေထွက်ကို စစ်ပေးပါမယ်။

---

## ၂၀။ သောက်စရာ ပြန်ဖြည့်ခြင်း / ရေခဲနှင့် သကြား

**C:** Could we have less ice in the drink?  
**中文:** 饮料可以少冰吗？ *Yǐnliào kěyǐ shǎo bīng ma?*  
**BM:** Boleh kurang ais dalam minuman?  
**မြန်မာ:** သောက်စရာကို ရေခဲနည်းနည်းပဲ ထည့်ပေးလို့ရမလား။

**W:** I’ll note that: less ice.  
**中文:** 好的，我记下了：少冰。 *Hǎo de, wǒ jì xià le: shǎo bīng.*  
**BM:** Baik, saya catat: kurang ais.  
**မြန်မာ:** ဟုတ်ကဲ့၊ ရေခဲနည်းနည်းလို့ မှတ်ထားပါမယ်။

**C:** Could we have another bottle of water?  
**中文:** 可以再给我们一瓶水吗？ *Kěyǐ zài gěi wǒmen yì píng shuǐ ma?*  
**BM:** Boleh tambah sebotol air?  
**မြန်မာ:** ရေတစ်ဘူး ထပ်ပေးလို့ရမလား။

**W:** Certainly. I’ll bring one more bottle.  
**中文:** 当然可以，我再拿一瓶给您。 *Dāngrán kěyǐ, wǒ zài ná yì píng gěi nín.*  
**BM:** Boleh, saya bawakan sebotol lagi.  
**မြန်မာ:** ရပါတယ်၊ ရေတစ်ဘူး ထပ်ယူလာပေးပါမယ်။

---

## ၂၁။ ကလေး / အသက်ကြီးသူ / အထူးလိုအပ်ချက်

**C:** Could we have a table that is easier for an elderly person to access?  
**中文:** 可以安排一张方便老人进出的桌子吗？ *Kěyǐ ānpái yì zhāng fāngbiàn lǎorén jìnchū de zhuōzi ma?*  
**BM:** Boleh beri meja yang mudah untuk warga emas?  
**မြန်မာ:** အသက်ကြီးသူ လွယ်လွယ်ကူကူ သွားလာနိုင်တဲ့ စားပွဲ ရှိလား။

**W:** I’ll check which table is most suitable and confirm with you.  
**中文:** 我确认一下哪张桌子最合适，再告诉您。 *Wǒ quèrèn yíxià nǎ zhāng zhuōzi zuì héshì, zài gàosu nín.*  
**BM:** Saya semak meja yang paling sesuai dan maklumkan kepada anda.  
**မြန်မာ:** ဘယ်စားပွဲက သင့်တော်လဲ အရင်စစ်ပြီး ပြန်ပြောပါမယ်။

**C:** My child cannot eat spicy food.  
**中文:** 我的孩子不能吃辣。 *Wǒ de háizi bù néng chī là.*  
**BM:** Anak saya tidak boleh makan pedas.  
**မြန်မာ:** ကျွန်တော့်ကလေး စပ်တာမစားနိုင်ပါဘူး။

**W:** I’ll check which items are suitable and confirm the ingredients.  
**中文:** 我确认适合的菜，并核对食材。 *Wǒ quèrèn shìhé de cài, bìng héduì shícái.*  
**BM:** Saya semak hidangan yang sesuai dan sahkan bahan-bahannya.  
**မြန်မာ:** သင့်တော်တဲ့ဟင်းနဲ့ ပါဝင်ပစ္စည်းကို စစ်ပြီး ပြန်ပြောပါမယ်။

---

## ၂၂။ ပစ္စည်းပျောက် / ဖုန်း၊ အိတ်၊ ထီး မေ့ကျန်ခြင်း

**C:** I think I left my phone here. Could you help me check?  
**中文:** 我觉得我把手机忘在这里了，可以帮我找找吗？ *Wǒ juéde wǒ bǎ shǒujī wàng zài zhèlǐ le, kěyǐ bāng wǒ zhǎozhao ma?*  
**BM:** Saya rasa tertinggal telefon di sini. Boleh bantu saya periksa?  
**မြန်မာ:** ဖုန်းကို ဒီမှာ မေ့ကျန်ခဲ့တယ်ထင်တယ်။ စစ်ပေးလို့ရမလား။

**W:** I’ll check the table and lost-and-found area with my manager.  
**中文:** 我会和经理一起检查桌子和失物招领处。 *Wǒ huì hé jīnglǐ yìqǐ jiǎnchá zhuōzi hé shīwù zhāolǐng chù.*  
**BM:** Saya periksa meja dan tempat barang hilang bersama pengurus.  
**မြန်မာ:** မန်နေဂျာနဲ့အတူ စားပွဲနဲ့ lost-and-found နေရာကို စစ်ပေးပါမယ်။

**C:** It is a black phone with a blue case.  
**中文:** 是一部黑色手机，蓝色手机壳。 *Shì yí bù hēisè shǒujī, lán sè shǒujī ké.*  
**BM:** Telefon hitam dengan sarung biru.  
**မြန်မာ:** အပြာရောင် cover နဲ့ အမည်းရောင်ဖုန်းပါ။

**W:** Thank you. Please wait here while we check.  
**中文:** 谢谢，请在这里等我们确认。 *Xièxie, qǐng zài zhèlǐ děng wǒmen quèrèn.*  
**BM:** Terima kasih. Sila tunggu di sini sementara kami periksa.  
**မြန်မာ:** ကျေးဇူးပါ။ ကျွန်တော်တို့ စစ်နေတုန်း ဒီမှာ စောင့်ပေးပါ။

---

## ၂၃။ Customer က မန်နေဂျာကို တွေ့ချင်ခြင်း

**C:** Could I speak to the manager, please?  
**中文:** 可以请经理过来吗？ *Kěyǐ qǐng jīnglǐ guòlái ma?*  
**BM:** Boleh saya bercakap dengan pengurus?  
**မြန်မာ:** မန်နေဂျာနဲ့ စကားပြောလို့ရမလား။

**W:** Certainly. I’ll call the manager now. Please give us a moment.  
**中文:** 当然可以，我现在叫经理。请稍等。 *Dāngrán kěyǐ, wǒ xiànzài jiào jīnglǐ. Qǐng shāo děng.*  
**BM:** Boleh. Saya panggil pengurus sekarang. Sila tunggu sebentar.  
**မြန်မာ:** ရပါတယ်။ အခု မန်နေဂျာကို ခေါ်လိုက်ပါမယ်။ ခဏစောင့်ပေးပါ။

**C:** I would like to explain what happened.  
**中文:** 我想说明刚才发生的事情。 *Wǒ xiǎng shuōmíng gāngcái fāshēng de shìqing.*  
**BM:** Saya ingin menerangkan apa yang berlaku.  
**မြန်မာ:** ဖြစ်ခဲ့တာကို ရှင်းပြချင်ပါတယ်။

**W:** I understand. I’ll make sure the manager hears your concern.  
**中文:** 我明白，我会确保经理了解您的情况。 *Wǒ míngbái, wǒ huì quèbǎo jīnglǐ liǎojiě nín de qíngkuàng.*  
**BM:** Saya faham. Saya akan pastikan pengurus memahami perkara ini.  
**မြန်မာ:** နားလည်ပါတယ်။ မန်နေဂျာက ဒီကိစ္စကို သိအောင် ပြောပေးပါမယ်။

---

## ၂၄။ အော်ဒါက ဘယ်လောက်ကြာမလဲ / ပြန်အသိပေးခြင်း

**C:** How much longer will our food take?  
**中文:** 我们的食物还要多久？ *Wǒmen de shíwù hái yào duō jiǔ?*  
**BM:** Berapa lama lagi makanan kami?  
**မြန်မာ:** ကျွန်တော်တို့ အစားအစာ ဘယ်လောက်ကြာ ထပ်စောင့်ရမလဲ။

**W:** I’ll check the exact status now. I don’t want to give you an incorrect estimate.  
**中文:** 我现在确认具体进度，不想给您错误的估计。 *Wǒ xiànzài quèrèn jùtǐ jìndù, bù xiǎng gěi nín cuòwù de gūjì.*  
**BM:** Saya semak status sebenar sekarang. Saya tidak mahu beri anggaran yang salah.  
**မြန်မာ:** အခု အော်ဒါအခြေအနေကို တိတိကျကျ စစ်ပေးပါမယ်။ မမှန်တဲ့ ခန့်မှန်းချိန် မပြောချင်ပါဘူး။

**W:** Thank you for waiting. It is being prepared now; I’ll update you again shortly.  
**中文:** 谢谢您的耐心，现在正在准备，很快再向您更新。 *Xièxie nín de nàixīn, xiànzài zhèngzài zhǔnbèi, hěn kuài zài xiàng nín gēngxīn.*  
**BM:** Terima kasih kerana menunggu. Pesanan sedang disediakan dan saya akan maklumkan semula sebentar lagi.  
**မြန်မာ:** စောင့်ပေးတာ ကျေးဇူးပါ။ အခု ပြင်ဆင်နေပါတယ်။ ခဏနေ ပြန်အသိပေးပါမယ်။

---

## ၂၅။ အဆုံးမှာ ဘာမှမလိုတော့ကြောင်း အတည်ပြုခြင်း

**W:** Is there anything else you need before I leave?  
**中文:** 在我离开前，还需要其他东西吗？ *Zài wǒ líkāi qián, hái xūyào qítā dōngxi ma?*  
**BM:** Ada apa-apa lagi yang anda perlukan sebelum saya pergi?  
**မြန်မာ:** ကျွန်တော် မသွားခင် နောက်ထပ် လိုတာရှိသေးလား။

**C:** No, that’s all for now. Thank you.  
**中文:** 没有了，暂时就这些，谢谢。 *Méiyǒu le, zànshí jiù zhèxiē, xièxie.*  
**BM:** Tiada, itu sahaja buat masa ini. Terima kasih.  
**မြန်မာ:** မရှိတော့ပါဘူး၊ အခုတော့ ဒါပဲပါ။ ကျေးဇူးပါ။

**W:** You’re welcome. Please let me know if you need anything.  
**中文:** 不客气，需要什么请告诉我。 *Bú kèqi, xūyào shénme qǐng gàosu wǒ.*  
**BM:** Sama-sama. Beritahu saya jika perlu apa-apa.  
**မြန်မာ:** ရပါတယ်။ လိုအပ်တာရှိရင် ပြောပါ။
