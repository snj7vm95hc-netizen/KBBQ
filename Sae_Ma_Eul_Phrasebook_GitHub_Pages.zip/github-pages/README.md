# Sae Ma Eul Puchong Phrasebook

Mobile-friendly static PWA for Sae Ma Eul Korean BBQ, Puchong. It contains Customer–Waiter phrases in English, Simplified Chinese with Pinyin, Bahasa Melayu, and Burmese, plus four core audio players.

## GitHub Pages

1. Upload the contents of this folder to the root of a GitHub repository.
2. In **Settings → Pages**, select **Deploy from a branch**.
3. Choose the `main` branch and `/ (root)`, then save.
4. Open the generated Pages URL on a phone and use **Add to Home Screen** or **Install app**.

Keep `index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`, `.nojekyll`, and the `audio/` folder together in the repository root.
